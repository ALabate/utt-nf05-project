#include "node.h"


Node::Node() {}


Node::~Node() {}


Calculable* Node::execute(){ return NULL; }


QString Node::toString() const { return ""; }
